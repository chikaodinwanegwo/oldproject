/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projecttwo;
/**
 *
 * @author chikaodinwanegwo
 */
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Project2 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField textField_4;
	private boolean check=false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Project2 frame = new Project2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Project2() {
		
		//list for automobiles
        ArrayList <Automobile> auto = new ArrayList<>();
        
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 343);
		contentPane = new JPanel();
		contentPane.setForeground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JLabel lblNewLabel = new JLabel("Make and Model");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(78, 26, 111, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblSalesPrice = new JLabel("Sales Price");
		lblSalesPrice.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSalesPrice.setBounds(78, 60, 82, 23);
		contentPane.add(lblSalesPrice);
		
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				
				
				
				
			}
			@Override
			public void keyPressed(KeyEvent e) {
				
				
					
			}
		});
		textField.setBounds(222, 28, 98, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				
				char c = e.getKeyChar();
				
				if(e.getKeyChar()>='0' && e.getKeyChar() <='9' || e.getKeyChar()=='.' || e.getKeyChar()== KeyEvent.VK_BACK_SPACE)
				{
					
				}
				
				else
				{
					JOptionPane.showMessageDialog(null, "Incorrect input, Enter value again");
					textField_1.setText("");
				}
			}
		});
		textField_1.setColumns(10);
		textField_1.setBounds(222, 62, 98, 20);
		contentPane.add(textField_1);
		
		JLabel lblAuto = new JLabel("Automobile Type");
		lblAuto.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAuto.setBounds(39, 101, 135, 23);
		contentPane.add(lblAuto);
		
		JRadioButton hybridbtn = new JRadioButton("Hybrid");
		buttonGroup.add(hybridbtn);
		hybridbtn.setFont(new Font("Tahoma", Font.BOLD, 11));
		hybridbtn.setBounds(39, 129, 82, 23);
		contentPane.add(hybridbtn);
		
		JRadioButton electricbtn = new JRadioButton("Electric");
		buttonGroup.add(electricbtn);
		electricbtn.setFont(new Font("Tahoma", Font.BOLD, 11));
		electricbtn.setBounds(39, 156, 82, 23);
		contentPane.add(electricbtn);
		
		JRadioButton otherbtn = new JRadioButton("Other");
		buttonGroup.add(otherbtn);
		otherbtn.setFont(new Font("Tahoma", Font.BOLD, 11));
		otherbtn.setBounds(39, 182, 82, 23);
		contentPane.add(otherbtn);
		
	
		
		JLabel lblMilesPerGallon = new JLabel("Miles per Gallon");
		lblMilesPerGallon.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblMilesPerGallon.setBounds(206, 130, 123, 23);
		contentPane.add(lblMilesPerGallon);
		
		JLabel lblWeightInPounds = new JLabel("Weight in Pounds");
		lblWeightInPounds.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblWeightInPounds.setBounds(206, 158, 123, 23);
		contentPane.add(lblWeightInPounds);
		
		
		
		textField_2 = new JTextField();
		textField_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				
				char c = e.getKeyChar();
				
				if(e.getKeyChar()>='0' && e.getKeyChar() <='9' || e.getKeyChar()=='.' || e.getKeyChar()== KeyEvent.VK_BACK_SPACE)
				{
					
				}
				
				else
				{
					JOptionPane.showMessageDialog(null, "Incorrect input, Enter value again");
					textField_2.setText("");
				}
			}
		});
		textField_2.setColumns(10);
		textField_2.setBounds(326, 130, 70, 20);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				char c = e.getKeyChar();
				
				if(e.getKeyChar()>='0' && e.getKeyChar() <='9' || e.getKeyChar()=='.' || e.getKeyChar()== KeyEvent.VK_BACK_SPACE)
				{
					
				}
				
				else
				{
					JOptionPane.showMessageDialog(null, "Incorrect input, Enter value again");
					textField_3.setText("");
				}
			}
		});
		textField_3.setColumns(10);
		textField_3.setBounds(326, 157, 70, 20);
		contentPane.add(textField_3);
		
		JButton btnNewButton = new JButton("Compute Sales Tax");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				
				
				
				if(hybridbtn.isSelected())
				{
					Hybrid hyb = new Hybrid(textField.getText(), Double.parseDouble(textField_1.getText()), Double.parseDouble(textField_2.getText()));
					textField_4.setText(String.valueOf(hyb.getSalesTax()));
					
					if (auto.size()<5)
					{
			            auto.add(hyb);
			        }
					else
					{
			           auto.remove(0);
			           auto.add(hyb);
			        }
					
					
				}
				
				else if(electricbtn.isSelected())
				{
					Electric ele = new Electric(textField.getText(), Double.parseDouble(textField_1.getText()), Double.parseDouble(textField_3.getText()));
					textField_4.setText(String.valueOf(ele.getSalesTax()));
					
					if (auto.size()<5)
					{
			            auto.add(ele);
			        }
					else
					{
			           auto.remove(0);
			           auto.add(ele);
			        }
					
				}
				
				
				
				
		    }
			
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBounds(68, 231, 148, 23);
		contentPane.add(btnNewButton);
		
		JButton btnClearFi = new JButton("Clear Fields");
		btnClearFi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
			}
		});
		btnClearFi.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnClearFi.setBounds(69, 265, 148, 23);
		contentPane.add(btnClearFi);
		
		JButton btnDisplayReport = new JButton("Display Report");
		btnDisplayReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				for(int i=0; i< auto.size();i++)
				{
					System.out.print(auto.get(i).toString() + "\n\n");
				}
				
			}
		});
		btnDisplayReport.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnDisplayReport.setBounds(227, 265, 148, 23);
		contentPane.add(btnDisplayReport);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.CYAN);
		panel.setBorder(new LineBorder(Color.BLUE));
		panel.setBounds(30, 99, 383, 111);
		contentPane.add(panel);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(229, 232, 144, 20);
		contentPane.add(textField_4);
	}
}

