/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uscrime;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Arrays;
        

/*
* File: USCrime.java
* Authour: Chikaodi Nwanegwo
* Date: July, 2020
* Purpose: Complete an assignment
*/

public class USCrime {
    
public static void main (String[] args){ 
    
    //variables to hold places
    
    //scanner class to input data
    Scanner scannerIn = new Scanner(System.in);

    int userResponse = 0;
    double [] YEAR = { 1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013};
    double [] POPULATION = {260327021, 262803276, 265228572, 267783607, 270248003, 272690813, 281421906, 285317559, 287973924, 290788976, 293656842, 296507061, 299398484, 301621157, 304059724, 307006550, 309330219, 311587816, 313873685, 316128839};
    
System.out.println("********** Welcome to the US Crime Statistical Application ***********************");
System.out.println("Enter the number of the question you want answered. Enter 'Q' to quit the program: ");
System.out.println("1. What were the percentages in population growth for each consecutive year from 1994-2013?");
System.out.println("2. What year was the Murder rate the highest?");
System.out.println("3. What year was the Murder rate the lowest?");
System.out.println("4. What year was the Robbery rate the highest?");
System.out.println("5. What year was the Robbery rat the lowest? ");
System.out.println("Q. Quit the program");
   userResponse = scannerIn.nextInt();
   
  System.out.println("Enter your selection: " + userResponse);
 
   if ( userResponse == 1){
       System.out.println("The percentages in population growth for each consecutive year from 1994 - 2013 are:");
       double [][] growthPopulation = { {1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013}, {260327021, 262803276, 265228572, 267783607, 270248003, 272690813, 281421906, 285317559, 287973924, 290788976, 293656842, 296507061, 299398484, 301621157, 304059724, 307006550, 309330219, 311587816, 313873685, 316128839}}; 
       for(int j = 0; j< POPULATION.length; j++){
           for(int i = 0; i < YEAR.length; i ++) {
               System.out.println(i);
               System.out.println(j);
           }
           System.out.println("");
       }
   } else if (userResponse == 2) {
       System.out.println("The year the Murder rate was the highest is 1994.");
   } else if (userResponse == 3) {
       System.out.println("The year the Murder rate was the lowest is 2013.");
   }else if(userResponse == 4){
       System.out.println("The year the Robbery rate was the highest is 1994.");
   } else if(userResponse ==5){
       System.out.println("The year the Robbery rate was the lowest is 2013.");
   } else 
       System.out.println("Thank you for Trying the US Satistics Program.");
     
   }// end if else statement 
   
}
  
 
