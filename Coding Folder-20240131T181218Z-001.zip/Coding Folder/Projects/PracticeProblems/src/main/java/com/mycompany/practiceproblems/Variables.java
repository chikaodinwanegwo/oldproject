/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practiceproblems;

/**
 *
 * @author chikaodinwanegwo
 */
public class Variables {
    public static void main(String[] args){
        final char UP = 'U';
        byte initialLevel = 12;
        short location = 13250;
        int score = 3500100;
        boolean newGame = true;
        
        System.out.println("You have reached level" +initialLevel + "with a score of" + score + "at location" +location+ ".");
        System.out.println("Press " +UP + "to go up.");
        System.out.println("Is this a new game?" +newGame);
     
        
    
    }
}
