/*
 * Week7Discussion
 * Chikaodi Nwanegwo
 * 
 **/


import java.util.Vector;

public class Week7Discussion {

    public static void main(String[] args) {
        nonGenericItems();
        genericItems();
        
       
    }
    
    

    private static void nonGenericItems() {
        Vector items = new Vector();

        items.add(new Items("Two Cases of Bottled Water"));
        items.add(new Items("Bread"));
        items.add(new Items("Milk"));
        items.add(new Items("Eggs"));
        items.add(new Items("Cereal"));
        
       
        for (int i=0; i<items.size(); i++) {
            Items listOfItem = (Items) items.get(i); 
              System.out.println("I need  " +listOfItem.getFood());
           
        }
    }

    
    private static void genericItems() {
        Vector<Items> list = new Vector<Items>();

        list.add(new Items("Rice"));
        list.add(new Items("Sugar"));
        list.add(new Items("Tea"));
        list.add(new Items("Coffe"));
       
        for (int i=0; i<list.size(); i++) {
            Items listOfItem = list.get(i);
             System.out.println("I need  " +listOfItem.getFood());
            
        }
    }
}

class Items {
    private String food;

    Items(String food) {
        this.food = food;
    }

    public String getFood() {
        return food;
    }
}