/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package discussions;

import java.util.Random;

class Discussions {
	public static void main(String args[]) {
		try {
			Random r = new Random();
			int low = 0;
			int high = Integer.parseInt(args[1]);
			
			for(int count=1; count <= Integer.parseInt(args[0]); count++)	{
				int result = r.nextInt(high-low) + low;
				System.out.println("Random number between "+low+" and "+high+": "+result);
			}
				
		}
		catch(Exception e) {
			System.out.println("Exception: Please insert input in command line");
		}
		
	}
}