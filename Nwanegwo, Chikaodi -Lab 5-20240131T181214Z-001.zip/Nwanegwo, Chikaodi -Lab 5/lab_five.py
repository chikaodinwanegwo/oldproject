"""
__filename__ = " lab_five.py"
__coursename__ = "SDEV 300 -Building Secure Web Applications"
__author__ = "Chikaodi Nwanegwo"
__credits__ = ["Chikaodi Nwanegwo"]
__license__ = "IDK"
__Version__ = "1.0.0"
__maintainer__ = "Chikaodi Nwanegwo"
__email__ = "cnwanegwo@student.umgc.edu"
__status__ = "Baseline"



import os
import pyplot as plt
import pandas as pd

"""



import os


from matplotlib import pyplot as plt
import pandas as pd

LOC_POP_CHANGE = "/PopChange.csv"
LOC_HOUSING = "/Housing.csv"


def data_dump(data_frame, column):
    """
    Used to analyze columns

    """
    pd.set_option('precision', 2)
    pd.set_option('display.float_format', '{:,.2f}'.format)
    # plt.ticklabel_format(style='plain')
    print(f"You selected {column}")
    print("The statistics for this column are:")
    print(data_frame[column].describe())
    plt.hist(data_frame[column], edgecolor='black')
    print("The histogram for this column is now displayed")
    plt.show()


def analyze_housing_data():
    """
    Used to display the analyzed housing data

    """
    data_frame = pd.read_csv(os.getcwd() + LOC_HOUSING)

    print("You selected housing data")

    choice = None

    while not choice:
        print("Select your choice:")
        print("1. Analyze 'AGE'")
        print("2. Analyze 'BEDRMS'")
        print("3. Analyze 'BUILT'")
        print("4. Analyze 'NUNITS'")
        print("5. Analyze 'ROOMS'")
        print("6. Analyze 'WEIGHT'")
        print("7. Analyze 'UTILITY'")
        print("8. Back")

        choice = input("Enter your choice (1 - 8): ")

        if choice == "1":
            data_dump(data_frame, "AGE")
            choice = None
        elif choice == "2":
            data_dump(data_frame, "BEDRMS")
            choice = None
        elif choice == "3":
            data_dump(data_frame, "BUILT")
            choice = None
        elif choice == "4":
            data_dump(data_frame, "NUNITS")
            choice = None
        elif choice == "5":
            data_dump(data_frame, "ROOMS")
            choice = None
        elif choice == "6":
            data_dump(data_frame, "WEIGHT")
            choice = None
        elif choice == "7":
            data_dump(data_frame, "UTILITY")
            choice = None
        elif choice == "8":
            break
        else:
            choice = None


def analyze_population_data():
    """
    Used to display the analyzed population data
    """
    pd.set_option('precision', 2)
    pd.set_option('display.float_format', '{:,.2f}'.format)
    data_frame = pd.read_csv(os.getcwd() + LOC_POP_CHANGE)
    data_frame.columns = ["id", "geography", "tgi", "tgi2", "pop_apr1", "pop_jul1", "delta"]

    print("You selected population data")

    choice = None

    while not choice:
        print("Select your choice:")
        print("1. Analyze Pop Apr 1")
        print("2. Analyze Pop Jul 1")
        print("3. Change Pop")
        print("4. Back")

        choice = input("Enter your choice (1 - 4): ")

        if choice == "1":
            data_dump(data_frame, "pop_apr1")
            choice = None
        elif choice == "2":
            data_dump(data_frame, "pop_apr1")
            choice = None
        elif choice == "3":
            data_dump(data_frame, "delta")
            choice = None
        elif choice == "4":
            break
        else:
            choice = None


def main_menu():
    """
    This is the first/main menu the user gets
    for the Data analysis
    """
    choice = None

    while not choice:
        print('*' * 88)
        print("Welcome to  the Python Data Analysis App")
        print("Select your choice:")
        print("1. Population Data")
        print("2. Housing Data")
        print("3. Exit the Program")

        choice = input("Choice (1-3): ")

        if choice == "1":
            analyze_population_data()
            choice = None
        elif choice == "2":
            analyze_housing_data()
            choice = None
        elif choice == "3":
            print("You have chosen to exit this app.")
            break
        else:
            print("To use this application, Enter a number 1-3.")
            choice = None


main_menu()
