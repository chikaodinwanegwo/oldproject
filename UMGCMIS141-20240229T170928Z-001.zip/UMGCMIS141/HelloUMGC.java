/**
*CMIS141 Week 1 Discussion
*/

 public class HelloUMGC{
   public static void main(String[] args){
   //Personal Greeting
   System.out.println("Hello Everyone! Greetings Fellow  UMGC Students and Staff! ");
  }
}
