/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author chikaodinwanegwo
 */
public class Test {
    static int x;
    
    public static String recursive(int x) {
        if (x <= 1) {
            return String.valueOf(x);
        }
        //make the method recursive by calling itself
        return  recursive(x / 2) + String.valueOf(x % 2);
    }
   static String iterative(int x){
       int[] binaryArray = new int[32];
       int i = 0;
       String s = new String("");
       //while loop to calculate the binary number
     while(x > 0){
         binaryArray[i] = x % 2;
         x = x/2;
         i++;
   } 
     //for loop to reverse the order
     for (int y = i -1; y >= 0; y--){
         s = s + binaryArray[y];
     }
     return s;
   }
   
   public static void main(String[] args){
       Scanner in = new Scanner(System.in);
       System.out.println("This program will determine a binary number based on your input.");
       System.out.println("Please enter a postive integer");
       x = in.nextInt();
       System.out.println("This was calculated with a recusive method:  " +recursive(x));
       System.out.println("This was calculated with an iterative method:  "  +iterative(x));
       
   }
    
}
