/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class StringBufferTest {
    public static void main(String[] args){
        StringBuffer sb = new StringBuffer("Welcome Admin");
        System.out.println(sb.toString());
        
        System.out.println("sb length: " +sb.length());
        sb.reverse();
        sb.insert(0, "Hello");
        System.out.println(sb.toString());
        
        for(int i = 0; i < 10; i++)
            sb.append((char)(Math.random() * 100));
        System.out.println(sb.toString());
    }
    
}
