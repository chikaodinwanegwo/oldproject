/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
/**
 *
 * @author chikaodinwanegwo
 */


//Allows you loop through Vectors
class Horse
{
    int number;
    
    public Horse(int i)
    {
         number = i;
    }
}
public class CatEnumerator {
    public static void main(String[] args)
    {
        Vector horse = new Vector();
        //add cats
        for(int i = 0; i< 5; i++)
            horse.add(new Horse(i));
        
        //show all cats
        Enumeration e = horse.elements();
        
        while (e.hasMoreElements())
            System.out.println("Cats number: " + ((Horse)
                    e.nextElement()).number);
                    
        
    }
    
}
