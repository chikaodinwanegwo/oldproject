/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class helloConstructorTest {
    public static void main(String[] args){
        new helloConstructor("Bored");
        new helloConstructor();
        new helloConstructor(2345);
       
        
    }
    
}
