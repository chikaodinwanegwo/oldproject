/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tipcalc;

/**
 *
 * @author chikaodinwanegwo
 */
public class Tip {
    private double mealCost;
    private double tipPercent;
    
    public Tip(double mealCost, double tipPercent){
        this.mealCost = mealCost;
        this.tipPercent = tipPercent;
        
    }// end constructor
    
    public double getTipAmount(){
        double tipAmount = this.mealCost * this.tipPercent;
        return tipAmount;
    }// get tipAmount
    
}// end Class
