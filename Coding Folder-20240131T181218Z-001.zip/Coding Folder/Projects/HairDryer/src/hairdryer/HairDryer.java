/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hairdryer;

/* 
*  File:    HairDryer.java
*  Author:  Ryan Garrett
*  Date:    25JUN2020
*  Purpose: Define a hair dryer
*/
public class HairDryer {

    // Set default variables
    private int fanSpeed = 0;
    private boolean isOn = false;
    private boolean isHot = false;

    // Default constructor
    HairDryer() {
    }
    // Full constructor
    HairDryer(int fanSpeed, boolean isHot, boolean isOn) {
        this.setFanSpeed(fanSpeed);
        this.setIsHot(isHot);
        this.setIsOn(isOn);
    }

    // Use the hairdryer
    String useHairDryer () {
        if (this.isOn) {
            if (this.isHot) {
                if (this.fanSpeed > 3) {
                    return "Hair dryer go BRRRRR.";
                } else {
                    return "Hair dryer go brrrrr.";
                }
            } else {
                if (this.fanSpeed > 3) {
                    return "Hair dryer go FWOOOO.";
                } else {
                    return "Hair dryer go fwoooo.";
                }
            }
        } else {
            return "The hair dryer is off and can not be used.";
        }
    }
    // Getters and setters
    public int getFanSpeed() {
        return fanSpeed;
    }
    public boolean getIsHot() {
        return isHot;
    }
    public boolean getIsOn() {
        return isOn;
    }
    public void setFanSpeed(int fanSpeed) {
        this.fanSpeed = fanSpeed;
    }
    public void setIsHot(boolean isHot) {
        this.isHot = isHot;
    }
    public void setIsOn(boolean isOn) {
        this.isOn = isOn;
    }
}
