/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
 class Dog {
     String name;
     String color;
     String diet;
     
     public Dog(String name1, String color1, String diet1){
         name = name1;
         color = color1;
         diet = diet1;
     }
     
     public Dog(String color1){
         color = color1;
     }
     
     public void eat(String food){
         diet = food;
         
     }
     
     public void bark(){
         System.out.println(" Dog " +name+ "can bark: Lol Lol Lol");
     }
    
     public void showDog(){
         System.out.println("Dog name: " + name);
         System.out.println("Dog color: " + color);
         System.out.println("Dog can eat food: " +diet);
     }
}

class PetDog extends Dog{
    String owner;
    
    public PetDog(String name, String color, String diet, String owner1){
        super(name, color, diet);
        owner = owner1;
    }
    
    public void showLove(){
        System.out.println("Dog " + name+ "can express love: Ich Ich Ich");
    }
}

class StrayDog extends Dog{
    public StrayDog(String color){
        super(color);
    }
    
    public void bite(){
        System.out.println("Beware: This stray Dog will bite");
    }
            
}

public class DogTest{
    public static void main(String[] args){
        PetDog pet = new PetDog("Tommy", "white", "meat", "Rajkumar");
        pet.showDog();
        pet.showLove();
        
        StrayDog found = new StrayDog( "Gray");
        found.bite();
        found.showDog();
        
    }
}
