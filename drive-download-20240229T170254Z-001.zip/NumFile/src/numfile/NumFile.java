/**
* Filename: NumFile.java
* Author: Maurice Martinez
* Date: July 10, 2020
* Purpose: Reads file and then echos them.
*/
package numfile;
// imports
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;


public class NumFile {

	public static void main(String[] args) throws FileNotFoundException {

	// command line arguement
	File intFile = new File(args[0]);

        // counter
	int counter = 0;

	// scans file
	Scanner in = new Scanner(intFile);

	System.out.println("\nIntegers in the file.\n");

	// prints and counts each integer
	while(in.hasNextLine()) {
	    System.out.println(in.nextInt());
	    counter++; }

	// prints the count
	System.out.println("\nNumber of integers: " + counter);
    }
}