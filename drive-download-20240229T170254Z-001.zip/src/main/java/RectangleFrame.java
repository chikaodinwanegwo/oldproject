/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author chikaodinwanegwo
 */
class Rect extends JPanel
{
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        g.setColor(Color.RED);
        g.drawString("Rectangles", 100, 50);
        g.drawRect(100, 100, 75, 50);// width = 75, height = 50
        g.setColor(Color.YELLOW);
        g.fillRect(200, 100, 75, 50);
        g.setColor(Color.BLUE);
        g.drawRoundRect(300, 100, 75, 50, 30, 30);// aw = 30, ah = 30
        g.setColor(Color.MAGENTA);
        g.fillRoundRect(100, 200, 75, 50, 30, 30);
        g.setColor(Color.GREEN);
        g.draw3DRect(200, 200, 75, 50, true);
        g.setColor(Color.CYAN);
        g.fill3DRect(300, 200, 75, 50, false);
        
        g.setColor(new Color(159, 182, 210));
        g.fillRect(100, 300, 75, 50);
        g.setXORMode(new Color(25,32, 250));
        g.fillRect(150, 325, 75, 50);
        g.setPaintMode();// restores to original colour mode
        g.fillRect(200, 350, 75, 50);
    }
}
public class RectangleFrame  extends JFrame{
    Rect panel = new Rect();
    
    public RectangleFrame()
    {
        add(panel);
        setTitle("Drawing Rectangles");
        setSize(500,500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args)
    {
        RectangleFrame x = new RectangleFrame();
    }
}
