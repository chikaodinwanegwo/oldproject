/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class CharacterTest {
    public static void main(String[] args){
        Character c = new Character('g');
        System.out.println(c.charValue());
        System.out.println("Character.isDigit('a'): " +Character.isDigit('g'));
        System.out.println("Character.isLetter('a'): " + Character.isLetter('g'));
        System.out.println("Character.toLowerCase('A'): " +Character.toLowerCase('g'));
        System.out.println("compare c and b: " +c.compareTo('b'));
        
    }
    
}
