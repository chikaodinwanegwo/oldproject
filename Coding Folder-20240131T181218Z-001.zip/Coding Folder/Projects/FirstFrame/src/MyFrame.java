/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author chikaodinwanegwo
 */
public class MyFrame extends JFrame 
{
    public MyFrame()
    {
        setTitle("First Frame");
        setSize(300, 200);
        getContentPane().setBackground(Color.magenta);
        setLocationRelativeTo(null);//Centers frame to screen
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// closes Frame
        setVisible(true);
        
    }
     public static void main(String[] args)
     {
         MyFrame f = new MyFrame();
     }
             
    
}
