/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projecttwo;
/**
 *
 * @author chikaodinwanegwo
 */
public class Electric extends Automobile {
    
    public double weight;
    
    public Electric(String makeModel, double purchasePrice, double weight ){
        super(makeModel, purchasePrice);
        this.weight = weight;
    }//end constructor
    
     public double getWeight(){
            return weight;
        }
        
        public void setWeight(){
            this.weight = weight;
        }
    
    @Override
    public double getSalesTax(){
        double salesTax = super.getSalesTax();
        if (weight < 3000){
            if(salesTax - 200 >= 0){
          return  salesTax - 200;
        } else {
                return 0.0;
            }
           } else { 
            if (salesTax - 150 >=0){
          return salesTax - 150;
            } else {
            return 0.0;
             }// end else statement
        }// end override statement for getSalesTax
      }
    @Override 
   public String toString(){
        
        return String.format("\n Make and Model:  " 
                + this.getMakeModel()
                +"\n Sales price: "+
                + this.getPurchasePrice() +
                "\n Sales Tax: " + this.getSalesTax()
                 + "\n Weight: " + this.getWeight()
                 + "Electric Car");
   }            

   }// end of toString class
     
    
    
