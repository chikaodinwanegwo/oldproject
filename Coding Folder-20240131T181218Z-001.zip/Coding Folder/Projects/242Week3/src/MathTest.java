/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class MathTest {
    public static void main(String[] args){
        System.out.println("abs(-100.0) : " +Math.abs(-100.0));
        System.out.println("sin(90): " + Math.sin(90));
        System.out.println("min(10,20): " + Math.min(10,20));
        System.out.println("pow(10,2): " +Math.pow(10,2));
        System.out.println("sqrt(25) : " +Math.sqrt(25));
        
        for(int i = 1; i <= 5; i++)
            System.out.println("Random number " + i + " : " + Math.random());
    }
    
}
