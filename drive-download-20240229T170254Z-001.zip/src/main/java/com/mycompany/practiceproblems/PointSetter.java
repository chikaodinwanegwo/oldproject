/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practiceproblems;
import java.awt.Point;
/**
 *
 * @author chikaodinwanegwo
 */
public class PointSetter {
    public static void main(String[] args){
        Point Location = new Point(4, 13);
        
        System.out.println(" Starting Location:  ");
        System.out.println("X equals:  " +Location.x);
        System.out.println("Y equals:  " +Location.y);
        
        System.out.println("\n Moving to (7, 6)");
        Location.x = 7;
        Location.y = 6;
        
        
        System.out.println("\n Ending location:  ");
        System.out.println("X equals " +Location.x);
        System.out.println("Y equals " +Location.y);
    }
    
}
