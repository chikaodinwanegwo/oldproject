/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.project3redo;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
/**
 *
 * @author chikaodinwanegwo
 */
public class Oval extends Shape {
    
    //parameterized ocnstructor
    public Oval(Point p, Dimension d, String color, String shape){
        super(p, d, color, shape);
    }

    @Override
    public void draw(Graphics g) {
        //drawing shape according to shape type
        if(getSolid().equalsIgnoreCase("hollow"))
            g.drawOval((int)getX(),(int)getY(),(int)getWidth(),(int)getHeight());
        else if(getSolid().equalsIgnoreCase("solid"))
            g.fillOval((int)getX(),(int)getY(),(int)getWidth(), (int)getHeight());
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
