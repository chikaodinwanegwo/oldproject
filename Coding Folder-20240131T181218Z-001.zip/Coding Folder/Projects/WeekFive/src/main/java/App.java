/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class App {
    public static void main(String[] args) throws Exception{
        DumpTruck dumpTruck = new DumpTruck();
        System.out.println(dumpTruck.load("Sand", 500));
        System.out.println(dumpTruck.unload());
        System.out.println(dumpTruck.ToggleTailgateLift());
        System.out.println(dumpTruck.reload());
        
        
        TransferTruck transferTruck = new TransferTruck();
        System.out.println(transferTruck.load("Electrics", 500));
        System.out.println(transferTruck.unload());
        System.out.println(transferTruck.ToggleCoupling());
        System.out.println(transferTruck.reload());
        System.out.println("\n Truck is heading back to the parking lot");
        
        
                
    }
    
}
