/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author chikaodinwanegwo
 */
public class LoginFrame extends JFrame{
    JLabel lblTitle = new JLabel ("User Login", JLabel.CENTER);
    JLabel lblUser = new JLabel("Enter User Name");
    JLabel lblPwd = new JLabel("Enter Password");
    
    JTextField tfUser = new JTextField(25);
    JPasswordField tfPWD = new JPasswordField(25);
    JButton bSubmit = new JButton("Submit");
    
    public LoginFrame() {
            //add title to North
            add( lblTitle, BorderLayout.NORTH);
            
            JPanel eb = new JPanel();
            
            eb.setLayout(new GridLayout(2, 2));
            eb.add(lblUser);
            eb.add(tfUser);
            eb.add(lblPwd);
            eb.add(tfPWD);
            
            add(eb);
            
            //add btn to south
            
            eb = new JPanel();
            eb.add(bSubmit);
            add(eb,BorderLayout.SOUTH);
            
            bSubmit.addActionListener(new bSubmitL());
            
    }
    class bSubmitL implements ActionListener{
        public void actionPerformed(ActionEvent e){
            System.out.println(tfUser.getText() + ":" + tfPWD.getText());
        }
    }
    
    public static void main(String[] args){
        LoginFrame ynz = new LoginFrame();
        ynz.setVisible(true);
        ynz.setTitle("Login Frame");
        ynz.setSize(450, 300);
        ynz.setLocationRelativeTo(null);
        ynz.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
