/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weekTwo.discussion;

/**
 *
 * @author jonmainhart
 */
public class Chair {

    private String constructionMaterial; // instance variables
    private int numberOfLegs;
    private boolean seatCushion;

    private static int numberOfChairs = 0; // class variable

    public Chair(String material, int legs, boolean cushion) {
        
        this.constructionMaterial = material;
        this.numberOfLegs = legs;
        this.seatCushion = cushion;
        numberOfChairs++;
    }
    
    @Override
    public String toString() {
        String returnString = ("\nConstruction Material: " + 
                this.constructionMaterial + "\nNumber of Legs: " + 
                this.numberOfLegs + "\nSeat Cushion: " +
                this.seatCushion);
        return returnString;
    } // end toString

} // end class Chair

