/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weekTwo.discussion;

/**
 *
 * @author jonmainhart
 */
public class Recliner extends Chair {
    
    private boolean reclines;
    private boolean swivels; 
    
    public Recliner(String material, int legs, boolean cushion, 
            boolean reclines, boolean swivels) {
        
        super(material, legs, cushion);
        this.reclines = reclines;
        this.swivels = swivels;
        
    }
    
    @Override
    public String toString() {
        String reclinerString = (super.toString() + "\nReclines: " + 
                this.reclines + "\nSwivels: " + this.swivels);
        return reclinerString;
    }
    
}
