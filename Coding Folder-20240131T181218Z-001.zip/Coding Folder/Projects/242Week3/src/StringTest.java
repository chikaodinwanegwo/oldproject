/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class StringTest {
    
   public static void main(String[] args){
       String s1 = new String("HELLO");
       char[] c = {'h', 'e', 'l', 'l', 'o'};
       String s2 = new String(c);
       
       System.out.println("s1.charAT(2): " +s1.charAt(2));
       //compareTo() returns -ve, 0, or +ve number if <, ==, or >
       
       System.out.println("s1.compareTo(s2): " +s1.compareTo(s2));
       System.out.println("s1.toLowerCase(): " +s1.toLowerCase());
       System.out.println("s2.toUpperCase(): " +s2.toUpperCase());
       System.out.println("s1.length(): " +s1.length());
   }
    
}
