/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java21;

/**
 *
 * @author chikaodinwanegwo
 */

public class MarsRobot {
    String status;
    int speed;
    float temperature;
    String name;
    
    
    void checkTemperature(){
        if( temperature < -80) {
            status = "returning home";
            speed = 5;
        }
    }
    
    void showAttributes(){
        System.out.println("Name : " +name);
        System.out.println("Status: " +status);
        System.out.println("Speed: " +speed);
        System.out.println("Temperature: " +temperature);
        
    }
    
    
}