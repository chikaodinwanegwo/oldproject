/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class LaptopTest {
    
    public static void main(String[] args){
        //create object ibm
        
        Laptop ibm = new Laptop();
        ibm.monitorSize = 14;
        ibm.color = "Black";
        ibm.processor = "Core2";
        ibm.ram = 32;
        ibm.hardDisk = 500;
        ibm.name = "IBM";
        
        // do operations
        // turn on laptop
        ibm.name();
        ibm.turnOn();
        
        //set it runniny
        
        ibm.running();
        
        
        //switch off now
        ibm.turnOff();
        
        // Creating more laptops
        
        Laptop hp = new Laptop();
        
        hp.color = "Silver";
        hp.hardDisk = 64;
        hp.monitorSize = 20;
        hp.processor = "The Best";
        hp.ram = 64;
        hp.name = "HP";
        
        hp.name();
        hp.turnOn();
        hp.running();
        hp.turnOff();
        
        
        Laptop dell = new Laptop();
        
        dell.color = "Yellow";
        dell.hardDisk = 64;
        dell.monitorSize = 32;
        dell.processor = "Giant4";
        dell.ram = 45;
        dell.name = "Dell";
        
        dell.name();
        dell.turnOn();
        dell.idle();
        
        
        Laptop lenova = new Laptop();
        lenova.color = "White";
        lenova.hardDisk = 34;
        lenova.monitorSize = 46;
        lenova.processor = "Boring";
        lenova.ram = 36;
        lenova.name = "Lenova";
        
        lenova.name();
        lenova.turnOn();
        lenova.running();
        lenova.idle();
        lenova.turnOff();
    }
    
}
