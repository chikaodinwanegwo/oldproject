/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tipcalc;

/**
 *
 * @author chikaodinwanegwo
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



public class GuiExample extends JFrame implements ActionListener{

  
   JLabel first,second,result;
   JButton add_but;
   JTextField n1,n2,r;

   GuiExample(){
   
       
       first =new JLabel("Enter Number 1");
       second =new JLabel("Enter Number 2");
       result =new JLabel("Add the two numbers");
      
       
       add_but=new JButton("ADD");

       
       n1=new JTextField(10);
       n2=new JTextField(10);
       r=new JTextField(10);
  

       
       add(first);
       add(n1);
       add(second);
       add(n2);
       add(result);
       add(r);
       add(add_but);

       add_but.addActionListener(this);

       
       setSize(300,300);
       setLayout(new GridLayout(0,2));
      
       setTitle("Calculator");
      
   }

   
   public void actionPerformed(ActionEvent ae){
   
           
           double x,y,r2;
          
           
           if(ae.getSource()==add_but){
           
               
               x=Double.parseDouble(n1.getText());
               y=Double.parseDouble(n2.getText());
              
              
               r2=x+y;
              
               
               r.setText(String.valueOf(r2));
               r.setEditable(false);

           }

   }
 
   public static void main(String args[]){
   
           
           GuiExample a=new GuiExample();
           a.setVisible(true);
           a.setLocation(200,200);

   }

}