/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class NwanegwoTest {
    public static void main(String[] args){
        Nwanegwo Chukwuemeka = new Nwanegwo();
        Chukwuemeka.name = "Chukwuemeka";
        Chukwuemeka.age = 27;
        Chukwuemeka.height = 64;
        Chukwuemeka.school = "Baltimore City Community College";
      
        Chukwuemeka.getName();
        Chukwuemeka.getAge();
        Chukwuemeka.getHeight();
        Chukwuemeka.getSchool();
    }
    
}
