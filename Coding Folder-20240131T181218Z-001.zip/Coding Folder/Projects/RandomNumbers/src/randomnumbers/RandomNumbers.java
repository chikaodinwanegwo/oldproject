/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package randomnumbers;

/*
 * File: RandomNumbers.java
 * Author: Chkaodi Nwanegwo
 * Date: July 2020
 * Purpose: This program generates
 * a number of random integers
 * based on user input from the command line
 * arguments
 */
public class RandomNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Default values
        int numInteger = 100;
              
     
        // Check to make sure we have command line argument
        if (args.length == 2) {
            numInteger = Integer.parseInt(args[0]);            
            System.out.println("Generating X: "
                    + args[0] + " Random Integers");
        } else {
            System.out.println("Application requires 2 command arguments");
            System.out.println("e.g. java RandomNumbers 10 100");
            System.exit(0);
        }
        for (int i=0 ; i<numInteger; i++){
            int randInt = (int) (Math.random() * 100);
            System.out.println("Random Int is between ( 0 and Y) " + randInt);
        }
    }

}


