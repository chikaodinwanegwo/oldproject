/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practiceproblems;

/**
 *
 * @author chikaodinwanegwo
 */
public class Discussion7 {
    
public static void main(String[] args) {
        GenericDemo<Integer, Integer> gInt = new GenericDemo<>(85, 95);
        GenericDemo<Double, Double> gDoub = new GenericDemo<>(2.4, 3.8);
       

        NonGenericIntDemo ngInt = new NonGenericIntDemo(85, 95);
        NonGenericDoubleDemo ngDoub = new NonGenericDoubleDemo(2.4, 3.8);

        System.out.println("Let's compare:");
        System.out.println("Average of two integers with a Generic class: " + gInt.avg());
        System.out.println("Average of same two with non-generic class: " + ngInt.avg() + "\n");
        System.out.println("Average of two doubles wit the same Generic class: " + gDoub.avg());
        System.out.println("Average of same two with non-generic class: " + ngDoub.avg());

    }
}

class GenericDemo<T extends Number, U extends Number> {

    T obj;
    U obj2;


    // Constructor
    public GenericDemo (T obj, U obj2){
        this.obj = obj;
        this.obj2 = obj2;

    } // end constructor

    // method to find the average of inputs
    public double avg(){
       return (obj.doubleValue() + obj2.doubleValue())/2;
    }
}  // end GenericDemo

class NonGenericIntDemo {
    int x;
    int y;

    // Constructor
    public NonGenericIntDemo(int x, int y){
        this.x = x;
        this.y = y;
    } // end constructor

    public double avg() {
        return (x + y)/2;
    }
} // end NonGenericIntDemo

class NonGenericDoubleDemo {
    double x;
    double y;

    // Constructor
    public NonGenericDoubleDemo(double x, double y){
        this.x = x;
        this.y = y;
    } // end constructor

    public double avg() {
        return (x + y)/2;
    }
} // end NonGenericDoubleDemo

