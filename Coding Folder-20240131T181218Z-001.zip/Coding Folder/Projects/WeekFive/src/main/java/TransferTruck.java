/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class TransferTruck implements Truck {
    private Boolean IsTrailerCoupled = true;
    private String LoadType;
    private Integer LoadWeight;
    
    public String ToggleCoupling(){
        IsTrailerCoupled = IsTrailerCoupled ? false: true;
        return (IsTrailerCoupled) ? "Trailer is coupled" : "Trailer is decoupled";
    }
    
    @Override
    public String load(String loadType, Integer weightInPounds){
        LoadType = loadType;
        LoadWeight = weightInPounds;
        return "Loaded" + LoadWeight + "Pound of" + LoadType;
     }
    @Override
    public String unload(){
        if (LoadType == null || LoadWeight <= 0) {
        return "Transfer truck is not loaded";
       } else {
               var response = "unoaded" + LoadWeight + "pounds of " + LoadType;
               LoadType = null;
               LoadWeight = 0;
               return response;
               }
    }
 @Override
 public String reload(){
     if (LoadType == null || LoadWeight <= 0){
         return "Transfer truck is not loaded";
     } else{
         var response = "Reloaded once more";
         LoadType = null;
         LoadWeight = 0;
         return response;
     }
 }
    
}
