/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.lang.*;
import javax.swing.plaf.DimensionUIResource;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
/**
 *
 * @author chikaodinwanegwo
 * 
 */

public class Project3  extends JFrame implements ActionListener {
    //Panels
    private JPanel contentPane;
    private JPanel shapeDrawing;
    Border blue;
   
    
    //define all components
    JComboBox<String> shapeType = new JComboBox<String>();
    JComboBox<String> fillType = new JComboBox<String>();
    JComboBox<String> color = new JComboBox<String>();
    JButton drawButton = new JButton();
    JTextField yCoordinate = new JTextField();
    JTextField height = new JTextField();
    JTextField width = new JTextField();
    JTextField xCoordinates = new JTextField();
    JTextField counter = new JTextField();
    
    
    public Project3() {
        // General Settings 
        setMinimumSize(new DimensionUIResource(650, 420));
        setMaximumSize(new DimensionUIResource(650, 420));
        setResizable(false);
        setVisible(true);
        setLayout(null);
        setTitle("Geometric Drawing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        contentPane = new JPanel(new GridLayout(0,2));
        

       
        //Shape Type
        JLabel NewLabel = new JLabel("Shape Type");
		NewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
	       contentPane.add(NewLabel);
               
         JComboBox<String>shapeType = new JComboBox<String>();
          shapeType.addItem("Oval");
          shapeType.addItem("Rectangle");
          contentPane.add(shapeType);
      
        JLabel NewLabel1 = new JLabel("Fill Type");
		NewLabel1.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(NewLabel1);
           
                // Fill Type
         JComboBox<String>fillType = new JComboBox<String>();
          fillType.addItem("Filled");
          fillType.addItem("Hallow");
          contentPane.add(fillType);
                
                
        JLabel NewLabel2 = new JLabel("Color");
		NewLabel2.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(NewLabel2);
                
                //Color
                
        JComboBox<String> color = new JComboBox<String>();
          color.addItem("Magenta");
          color.addItem("Black");
          color.addItem("Red");
          color.addItem("Orange");
          color.addItem("Yello");
          color.addItem("Green");
          color.addItem("Blue");
          contentPane.add(color);
          
          //width
          
        JLabel NewLabel3 = new JLabel("Width");
		NewLabel3.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(NewLabel3);
                
               width = new JTextField();
               contentPane.add(width);
               
               
               //height
                
        JLabel NewLabel4 = new JLabel("Height");
		NewLabel4.setFont(new Font("Tahoma", Font.BOLD, 13));
	
		contentPane.add(NewLabel4);
                 height = new JTextField();
		contentPane.add(height);
               
             //xCoordinates
        JLabel NewLabel5 = new JLabel("x coordinate");
		NewLabel5.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(NewLabel5);  
                xCoordinates = new JTextField();
		contentPane.add(xCoordinates);
                
        JLabel NewLabel6 = new JLabel("y coordinate");
		NewLabel6.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		contentPane.add(NewLabel6);
               yCoordinate = new JTextField();
		contentPane.add(yCoordinate);
        contentPane.setBounds(10, 10, 250, 300);  
        contentPane.setSize(250, 300);  
            add(contentPane);
           
       
        // Draw Button
        JPanel drawDrawButton = new JPanel(new GridLayout(0,1));
        JButton drawButton = new JButton("Draw");
		drawButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				
			}
                       
		});
                
        drawButton.setMinimumSize(new DimensionUIResource(80,40));
        drawButton.setFont(new Font("Tahoma", Font.BOLD, 13));
        drawDrawButton.setBounds(280, 320, 80, 40);
        drawDrawButton.add(drawButton);
        add(drawDrawButton);
        
        //Counter panel/label
                
                
               
        
        //ShapeDrawiing
        JPanel shapeDrawing = new Drawing();
        //shapeDrawing = new JPanel(new GridLayout( 10, 20));
        
        
       
        
        shapeDrawing.setBorder(BorderFactory.createTitledBorder("Shape Drawing"));
         var shapeDrawingSize = shapeDrawing.getPreferredSize();
        shapeDrawing.setBounds(400, 30, shapeDrawingSize.width, shapeDrawingSize.height);
           add(shapeDrawing);
        
        
        
         //JLabel One = new JLabel("Hellpo Oe else bbbbb");
		//NewLabel5.setFont(new Font("Tahoma", Font.BOLD, 13));
		//shapeDrawing.add(One);  
        
        
        
       
       
         
                
        
       
        
               
               
       
           //Create Border for shapeDrawing Panel
           
       
       // drawingPane = new JPanel(new GridLayout(0,1));
       // drawingPane.setVisible(true);
       // drawingPane.setBorder(BorderFactory.createTitledBorder("Shape Drawing"));
        //drawingPane.setBorder(BorderFactory.createLineBorder(Color.BLUE));
       // var drawingPaneSize = drawingPane.getPreferredSize();
       // drawingPane.setBounds(350, 10, drawingPaneSize.width, drawingPaneSize.height);
        // add(drawingPane);
        
        //JPanel shapeDrawing = new JPanel();
          //shapeDrawing.setBorder(BorderFactory.createLineBorder(Color.BLUE));
         // shapeDrawing.setBorder(BorderFactory.createTitledBorder("Shape Drawing"));
          //add(shapeDrawing);
          
         // Border blackline = BorderFactory.createLineBorder(Color.BLACK);
         // JPanel panel = new JPanel();
         // LayoutManager layout = new FlowLayout();
          //panel.setLayout(layout);
         // contentPane.add(panel);
        
        pack();
    }
   
         
                 
                 
                 
    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    public static void main(String[] args){
        Project3 Test = new Project3();
    }
    
    
    
   
    
}