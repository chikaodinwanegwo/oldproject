/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
/**
 *
 * @author chikaodinwanegwo
 */

//Vector class is a growable array of objects. If you have stuff in an array that you want to add/ remove. This is good for when you have an inventory.
public class CourseVector {
    public static void main(String[] args)
    {
        //Create a vector
        Vector v = new Vector();
        
        //courses hold strings
        
        String[] courses = {"BA", "BSc", "MCA", "BCA", "BE"};
        
        //add to v
        
        for(int i = 0; i<courses.length; i++)
        v.addElement(courses[i]);
        
        //retrieve second element
        System.out.println("Element 2:" + (String)v.elementAt(2));
        
        //add BArch to end of v
        
        v.add("BArch");
        
        //insert at 1
        v.add(1, "BCOM");
        
        //remove BCA
        v.removeElement("BCA");
        
        //remove at 0
        v.remove(0);
        
        //show elements using get()
        
        for(int i= 0; i<v.size(); i++)
            System.out.println((String)v.get(i));
    }
}
