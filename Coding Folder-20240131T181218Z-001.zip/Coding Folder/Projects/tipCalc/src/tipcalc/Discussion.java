/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tipcalc;

/**
 *
 * @author chikaodinwanegwo
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Discussion extends JFrame implements ActionListener{

  
   JLabel num1,num2,answer;
   JButton subt_but;
   JTextField x,y,z;

   Discussion (){
   
       
       num1 =new JLabel("Enter Current Year");
       num2 =new JLabel("Enter Current Age");
       answer =new JLabel("Calculate Year of Birth");
      
       
       subt_but=new JButton("YOB");

       
       x=new JTextField(10);
       y=new JTextField(10);
       z=new JTextField(10);
  

       
       add(num1);
       add(x);
       add(num2);
       add(y);
       add(answer);
       add(z);
       add(subt_but);

       subt_but.addActionListener(this);

       
       setSize(200,200);
       setLayout(new GridLayout(0,2));
      
       setTitle("Age Verification");
      
   }

   
   public void actionPerformed(ActionEvent ae){
   
           
           double w,e,p;
          
           
           if(ae.getSource()==subt_but){
           
               
               w =Double.parseDouble(x.getText());
               e =Double.parseDouble(y.getText());
              
              
               p=w-e;
              
               
               z.setText(String.valueOf(p));
               z.setEditable(false);

           }

   }
 
   public static void main(String args[]){
   
           
           Discussion a=new Discussion();
           a.setVisible(true);
           a.setLocation(200,200);

   }

}