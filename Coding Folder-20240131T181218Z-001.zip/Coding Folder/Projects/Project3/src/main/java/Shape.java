/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
      
/**
 *
 * @author chikaodinwanegwo
 */

public  abstract class Shape extends Rectangle  {
    private Color color;
    private String shapeFill;
    private static int count = 0;
    
    public Shape(Rectangle r, Color color, String shapeFill){
        super(r);
       color = color;
       shapeFill = shapeFill;
       count++;
        
    }
    
       public void setColor(Graphics g){
           g.setColor(color);
       }
        
    
      public String getSolid(){
        return shapeFill;
    }
    
    public int getNoOfShapes(){
        return count;
    }
    
   abstract void Draw(Graphics g);
      
   
}
