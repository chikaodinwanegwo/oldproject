/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class Laptop {
    int monitorSize;
    String color;
    String processor;
    int ram;
    int hardDisk;
    String name;
    
    void name(){
        System.out.println( name);
    }
    
    void turnOn(){
        System.out.println("Laptop swithed on now");
    }
    
    void turnOff(){
        System.out.println("Laptop swithed off now");
    }
    
    void idle(){
        System.out.println("Laptop is in idle mode now....");
       
    }
    void running(){
    System.out.println("Laptop is currently running ...");
    }
}
