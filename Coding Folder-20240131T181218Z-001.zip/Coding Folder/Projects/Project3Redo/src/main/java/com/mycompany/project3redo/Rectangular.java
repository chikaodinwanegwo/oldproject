/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.project3redo;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
/**
 *
 * @author chikaodinwanegwo
 */
public class Rectangular extends Shape {
    //parameterized constructor
    
    public Rectangular(Point p, Dimension d, String color, String shape){
        super(p,d, color, shape);
    }
    
    @Override
    public void draw(Graphics g){
        //drawing shape according to shape type
        if(getSolid().equalsIgnoreCase("hollow"))
            g.drawRect((int)getX(), (int)getY(), (int)getWidth(), (int)getHeight());
        else if(getSolid().equalsIgnoreCase("solid"))
            g.fillRect((int)getX(), (int)getY(), (int)getWidth(), (int)getHeight());
    }
}
