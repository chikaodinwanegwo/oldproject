/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
 class University {
    String name;
    String motto;
    int age;
    int avgSATScore;
    int avgGPA;
    
    public University(String name1, String motto1,int age1, int avgSATScore1, int avgGPA1 ){
        name = name1;
        motto = motto1;
        age = age1;
        avgSATScore = avgSATScore1;
        avgGPA = avgGPA1;
        
    }
    
    public University(
    String name1, int age1){
        name = name1;
        age = age1;
        
    }
    
    public University(String motto1){
        motto = motto1;
    }
    
    public University(int avgSATScore1, int avgGPA1){
        avgSATScore = avgSATScore1;
        avgGPA = avgGPA1;
        
    }
    
    public void getAll(){
        System.out.println("The name of this school is " +name);
        System.out.println("This schol was established in "  +age);
        System.out.println("The average GPA is  "  +avgGPA);
        System.out.println("The average SAT score is  "  +avgSATScore);
    }
       
}

class MorganState extends University{
    
    String president;
    
    public MorganState(String name, String motto, int age, int avgSATScore, int avgGPA , String president1){
        super(name, motto, age, avgSATScore, avgGPA);
        president = president1;
    }
    
    public void getName1(){
        System.out.print("This was not the orginal name of  " +name);
    }
    
}

public class TestUniversity{
    public static void main(String[] args){
       MorganState a = new MorganState(" Morgan State University", "Growing the Future, Leading the World",1867,1080, 3, "President Wilson");
       a.getAll();
       
        
        
    }
}