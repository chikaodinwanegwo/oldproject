/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package headphones;

/**
 *
 * @author chikaodinwanegwo
 */
public class HeadPhones {
 //set static Cconstants
     public static final int LOW = 1;
     public static final int MEDIUM = 2;
     public static final int HIGH = 3;
    // set fields
     private int volume = 2;
     private boolean pluggedIn = false;
     private String manufacturer;
     private String headPhoneColor;
     private String headPhoneModel;
     //getter method
     public int getVolume() {
         return volume;
     }
     public boolean getPluggedIn(){
         return pluggedIn;
     }
     public String getManufacturer(){
         return manufacturer;
     }
     public String getHeadPhoneColor(){
         return headPhoneColor;
     }
     public String getHeadPhoneModel(){
         return headPhoneModel;
     }
    //Setter Methods
     public void setVolume(int volume){
         this.volume = volume;
     }
    public void setPluggedIn(boolean pluggedIn){
        this.pluggedIn = pluggedIn;
    }
    public void setManufacturer(String manufacturer){
        this.manufacturer = manufacturer;
    }
    public void setColor(String headPhoneColor){
        this.headPhoneColor = headPhoneColor;
    }
    public void setModel(String headPhoneModel){
        this.headPhoneModel = headPhoneModel;
    }
     //no argument constructor
    public HeadPhones(){
    
    this.volume = 2;
        this.pluggedIn = false;
        this.manufacturer = "NO Default";
        this.headPhoneColor = "Brown";
        this.headPhoneModel = "UNKNOWN";
    }
    
    //Constructor 
    public HeadPhones(int volume, boolean pluggedIn, String manufacturer, 
            String headPhoneColor, String headPhoneModel){
        this.volume = volume;
        this.pluggedIn = pluggedIn;
        this.manufacturer = manufacturer;
        this.headPhoneColor = headPhoneColor;
        this.headPhoneModel = headPhoneModel;
    } //end no argument constructor
    //a toString() method
    public String toString(){
        return String.format("Head Phone volume is: %d"
                + "\nIs the Head Phones Pluggedin?: %s"
                + "\nWhats the name of the manufacturer?: %s"
                + "\nWhats the headPhone's color?: %s"
                + "\n Whats the headPhone's model?: %s", this.volume, this.pluggedIn,
                this.manufacturer, this.headPhoneColor, this.headPhoneModel);
            }// end toString
   //a changeVolume(Value) method
    public int changeVolume(int newVolume){
        this.volume = newVolume;
        return volume;
        }

        }
   
    

