/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projecttwo;
/**
 *
 * @author chikaodinwanegwo
 */
public class Hybrid extends Automobile {
    public double milesPerGallon;
    
    
    public Hybrid( String makeModel, double purchasePrice, double milesPerGallon ){
        super(makeModel, purchasePrice);
        this.milesPerGallon = milesPerGallon;
    }// end constructor
    
    public double getMilesPerGallon(){
        return milesPerGallon;
    }
    
    public void setMilesPerGallon(){
        this.milesPerGallon = milesPerGallon;
    }
    
 
        @Override 
        public double getSalesTax(){
        double salesTax = super.getSalesTax();
        if (milesPerGallon < 40){
            if(salesTax - 100 >=0){
                return salesTax - 100;
            } else{
                return 0.0;
            }
        }else{
            double discount = (this.milesPerGallon - 40) * 2;
            if (salesTax - discount - 100 >= 0){
                return salesTax - discount -100;
            } else {
                return 0.0;
            }
        }
    }

       
     public String toString(){
        
        return "Make and Model: " + this.getMakeModel() +
                "\n Sales aprice: " + this.getPurchasePrice() +
                "\n Sales Tax: " + this.getSalesTax() +
                "\n Hybrid Car "
                + "Miles Per Gallon: " + getMilesPerGallon();
               
                
    }// end of toString class
    
}
