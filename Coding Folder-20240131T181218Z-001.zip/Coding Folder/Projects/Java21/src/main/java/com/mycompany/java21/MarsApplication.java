/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java21;

/**
 *
 * @author chikaodinwanegwo
 */
public class MarsApplication {
    
   public static void main(String[] args)
   {
       //Spirit Robot
       MarsRobot spirit = new MarsRobot();
       spirit.name = "spirit";
       spirit.status = "exploring";
       spirit.speed = 2;
       spirit.temperature = -60;
       
       spirit.showAttributes();
       spirit.checkTemperature();
       System.out.println("Increasing speed to 3.");
       spirit.speed =3;
       spirit.showAttributes();
       System.out.println("Changing temperature to -90");
       spirit.temperature = -90;
       System.out.println("Checking the Temperature");
       spirit.checkTemperature();
       spirit.showAttributes();
       
       // Opportunity Robot
       MarsRobot opportunity = new MarsRobot();
       opportunity.name = "opportunity";
       opportunity.status = "tired";
       opportunity.speed = 1;
       opportunity.temperature = -100;
       
       opportunity.showAttributes();
       opportunity.checkTemperature();
       System.out.println("Increasing speed to 3.");
       opportunity.speed =3;
       opportunity.showAttributes();
       System.out.println("Changing temperature to -90");
       opportunity.temperature = -90;
       System.out.println("Checking the Temperature");
       opportunity.checkTemperature();
       opportunity.showAttributes();
       
       //Chikaodi
       
      MarsRobot Chikaodi = new MarsRobot();
      Chikaodi.name = "Chikaodi";
      Chikaodi.speed = 100;
      Chikaodi.status = "Working Hard";
      Chikaodi.temperature = 105;
      
      Chikaodi.showAttributes();
      Chikaodi.checkTemperature();
   }
    
}