/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class DumpTruck implements Truck {
    private Boolean IsTailgateLifted = false;
    private String LoadType;
    private Integer LoadWeight;
    
    public String ToggleTailgateLift(){
        IsTailgateLifted = IsTailgateLifted ? false: true;
        return (IsTailgateLifted) ? "Tailgate is lifted" : "Tailgate is lowered";
         
    }
    @Override
    public String load(String loadType, Integer weightInPounds) {
        LoadType = loadType;
        LoadWeight = weightInPounds;
        return "Loaded" + LoadWeight + "pounds of" + LoadType;
        
    }
    @Override 
    public String unload(){
        if (LoadType == null || LoadWeight <= 0){
            return "Dump truck is not loaded";
        } else {
            var response = "Unloaded" + LoadWeight + "pounds of " + LoadType;
            LoadType = null;
            LoadWeight = 0;
            return response;
        }
    }
    
     @Override
 public String reload(){
     if (LoadType == null || LoadWeight <= 0){
         return "Transfer truck is not loaded";
     } else{
         var response = "Reloaded once more";
         LoadType = null;
         LoadWeight = 0;
         return response;
     }
 }
    
}
