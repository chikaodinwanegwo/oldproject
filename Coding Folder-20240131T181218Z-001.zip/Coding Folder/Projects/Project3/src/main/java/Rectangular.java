/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Graphics;
/**
 *
 * @author chikaodinwanegwo
 */
public class Rectangular extends Shape{
    
public Rectangular (Rectangle r, Color color, String shapeFill){
    super(r, color, shapeFill);
}

@Override 
void Draw(Graphics g){
    if(super.getSolid() == "Fill"){
        g.fillRect(super.x, super.y, super.width, super.height);
    }else{
        g.drawRect(super.x, super.y, super.width, super.height);
    }
}
}


