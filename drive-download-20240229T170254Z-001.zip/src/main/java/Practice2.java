/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * @author chikaodinwanegwo
 */
public class Practice2 extends JFrame {
    public Practice2() {
        setLayout(new FlowLayout());
        
        for(int i = 0; i<10; i++){
            add(new JButton("Button" +i));
        }
}
    public static void main(String[] args){
        Practice2 fg = new Practice2();
        fg.setLocationRelativeTo(null);
        fg.setVisible(true);
        fg.setTitle("Flow Layout");
        fg.setSize(300, 200);
        fg.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    
}
