/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;

/**
 *
 * @author chikaodinwanegwo
 */
public class WeekSix {


   
    void stringIterative()
    {
      Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Your Name");
        String s = scanner.nextLine();
        scanner.close();
        System.out.println("You Entered  " +s);
        
        int length = s.length();
        StringBuffer rString = new StringBuffer();
        for(int i = length-1; i>=0; i--)
        {
            rString.append(s.charAt(i));
            
        }
        System.out.println(rString);
        
                
    }
    
      static String stringRecursion(String str)
    {
      
        
        if(str == null || str.length()<=1){
            return str;
        }
        
        return stringRecursion(str.substring(1)) + str.charAt(0);
    }
  

    
    public static void main(String[] args)
    {
        
        WeekSix x = new WeekSix();
         x.stringIterative();
       
       
}
    
}
