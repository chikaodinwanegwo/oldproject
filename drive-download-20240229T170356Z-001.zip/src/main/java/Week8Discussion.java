/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
import java.util.LinkedList;
/**
 *
 * @author chikaodinwanegwo
 */
public class Week8Discussion {
    public static void main (String[] args){
        //build and popuate initial structures
        ArrayList<Integer> arrayList = new ArrayList<>();
        LinkedList<Integer> linkedList = new LinkedList<>();
        
        for(int i = 0; i<5000; i++){
            arrayList.add(i);
            linkedList.add(i);
        }
        
        //first test is to pull item from center to index
        System.out.println("\nTest pulling an item from a central index of a list of 500 items long: \n");
        
        long aLstart = System.nanoTime();
        arrayList.get(1);
        long aLstop =System.nanoTime();
        
        long lLstart = System.nanoTime();
        linkedList.get(1);
        long lLstop = System.nanoTime();
        
        long aLresult = aLstop - aLstart;
        long lLresult = lLstop - lLstart;
        
        System.out.println("\tThe ArrayList completed the pull in " +aLresult);
        System.out.println("\tThe LinkedList completed the pull in " +lLresult);
        
        //makiing the data structures way bigger
        arrayList.clear();
        linkedList.clear();
        
        for(int i = 0; i< 5000000; i++){
            arrayList.add(i);
            linkedList.add(i);
        }
        
        //second test is to pull item from center index of 5000000 item list
        System.out.println("\tTest pulling an item from a central index of a list og 5,000,000 items long:   \n");
        aLstart = System.nanoTime();
        arrayList.get(2500000);
        aLstop = System.nanoTime();
      
        
        lLstart = System.nanoTime();
        linkedList.get(2500000);
        lLstop = System.nanoTime();
        
        
        aLresult = aLstop - aLstart;
        lLresult = lLstop - lLstart;
        
        System.out.println("\tThe ArrayList completed the pull in " +aLresult);
        System.out.println("\tThe LinkedList completed the pull in " +lLresult);
        
         if( aLresult < lLresult){
            System.out.println("ArrayList is Faster");
           
        }else {
            System.out.println("Linked List is Faster");
        }
        
        //third test test is removing the center index of 5,000,000 item list
        System.out.println("\nTest deleting the item from a central index of a list of 5,000,000 items long:  \n");
        
        aLstart = System.nanoTime();
        arrayList.remove(2500000);
        aLstop = System.nanoTime();
        
        lLstart = System.nanoTime();
        linkedList.remove(2500000);
        lLstop = System.nanoTime();
            
        
        aLresult = aLstop - aLstart;
        lLresult = lLstop - lLstart;
        
        System.out.println("\tThe ArrayList completed the deletion in " +aLresult);
        System.out.println("\tThe LinkedList completed the deletion in " +lLresult);
        
         if( aLresult < lLresult){
            System.out.println("ArrayList is Faster");
           
        }else {
            System.out.println("Linked List is Faster");
        }
        
        //forth test
        System.out.println("\nTest deleting three item, one at each third og a list 5,000,000 items long: \n");
        
        aLstart = System.nanoTime();
        arrayList.remove(1000000);
        arrayList.remove(2500000);
        arrayList.remove(4000000);
        aLstop = System.nanoTime();
        
        
        lLstart = System.nanoTime();
        linkedList.remove(1000000);
        linkedList.remove(2500000);
        linkedList.remove(4000000);
        lLstop = System.nanoTime();
        
        aLresult = aLstop - aLstart;
        lLresult = lLstop - lLstart;
        
        System.out.println("\tThe ArrayList completed the deletion in " +aLresult);
        System.out.println("\tThe LinkedList completed the deletion in " +lLresult);
        
        if( aLresult < lLresult){
            System.out.println("ArrayList is Faster");
           
        }else {
            System.out.println("Linked List is Faster");
        }
            
        
    }
    
}
