/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.*;
/**
 *
 * @author chikaodinwanegwo
 */
public class Practice extends JFrame{
    
    //compontents
    private JLabel xLabel;
    private JButton xButton;
    
    public Practice(){
        
        xLabel = new JLabel("User Frame", JLabel.CENTER);
        xButton = new JButton("Exit");
        
        xButton.setMnemonic('b');
        xButton.setToolTipText("Close Frame");
        
        add(xButton, BorderLayout.SOUTH);
        add(xLabel, BorderLayout.NORTH);
        
        xButton.addActionListener(new ZButton());
    }
    
     class ZButton implements ActionListener 
     {
         public void actionPerformed(ActionEvent e){
             System.exit(0);
         }
        
    }
    public static void main(String[] args){
        Practice y = new Practice();
        y.setVisible(true);
        y.setTitle("User Login");
        y.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        y.setSize(300, 200);
        y.setLocationRelativeTo(null);
    }
}
