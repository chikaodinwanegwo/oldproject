/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practiceproblems;

/**
 *
 * @author chikaodinwanegwo
 */
public class YourInvestment {
    
    public static void main(String[] args){
        
    float balance = 1400;
    float calculatebalance;
    
    System.out.println("You invested   " +balance);
    
    calculatebalance = (float) (balance * .4);
    
    balance = balance + calculatebalance;
    
    System.out.println("After the first year, your investment increased by 40%  to " +balance);
    
    balance = balance - 1500;
    
    System.out.println("After the second year, it went down by 1500 to  " +balance );
    
    calculatebalance = (float) (balance * .12);
    
    balance = balance + calculatebalance;
    
    System.out.println("So now, as we are ending the third year, it increased by 12% to  " +balance);
    
    int num1 = 86;
    int numb2 =55;
    
    System.out.println(num1/numb2+ "  /t " +numb2%num1);
    
    
    
    }
    
}
