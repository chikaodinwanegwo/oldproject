/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class StringBuilderTest {
    public static void main(String[] args){
        StringBuilder sb = new StringBuilder("Hello Java");
        
        sb.append(" How are You?");
        System.out.println("sb length: " +sb.length());
        System.out.println("sb reverse: " +sb.reverse());
        System.out.println("sn.insert: " +sb.insert(0, "Hello"));
        System.out.println(sb.toString());
    
   }
} 