/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author chikaodinwanegwo
 */
public class Buttons extends JFrame {
    private JLabel nameLabel;
    private JButton exitButton;
    
   public Buttons() {
       nameLabel = new JLabel("Login Frame", JLabel.CENTER);
       exitButton = new JButton("EXIT");
       
       exitButton.setMnemonic('b');
       exitButton.setToolTipText("Close Frame");
       
       add(nameLabel, BorderLayout.NORTH);
       add(exitButton, BorderLayout.SOUTH);
       
   }
 public static void main(String[] args){
     Buttons x = new Buttons();
     x.setVisible(true);
     x.setTitle("User Login");
     x.setSize(300, 200);
     x.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     x.setLocationRelativeTo(null);
 }
 
}