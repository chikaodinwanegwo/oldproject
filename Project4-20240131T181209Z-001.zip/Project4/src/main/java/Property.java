/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class Property implements StateChangeable {
        
    /* Declare Class Fields */
    protected String propertyAddress;
    protected int numberOfBedrooms;
    protected int squareFootage;
    protected int price;
    protected String statusOfProperty;

    
    public Property(String propertyAddress, int numberOfBedrooms, int squareFootage, int price)
    {
        this.propertyAddress = propertyAddress;

        this.numberOfBedrooms = numberOfBedrooms;

        this.squareFootage = squareFootage;

        this.price = price;

        statusOfProperty = String.valueOf(Status.FOR_SALE);

    }// end of Property constructor

   
    public Property( ) { }


 
    @Override
    public void changeState(Status n)
    {
        if(n == Status.FOR_SALE)
        {
            statusOfProperty = "For_Sale";
        }

        else if(n == Status.UNDER_CONTRACT)
        {
            statusOfProperty = "Under_Contract";
        }

        else if(n==Status.SOLD)
        {
            statusOfProperty = "Sold";
        }
    }// end of changeState method


    @Override
    public String toString( )
    {
        return "Property{" +
                "propertyAddress='" + propertyAddress + '\'' +
                ", numberOfBedrooms=" + numberOfBedrooms +
                ", squareFootage=" + squareFootage +
                ", price=" + price +
                ", statusOfProperty=" + statusOfProperty +
                '}';
    }// end of toString method

    
}
