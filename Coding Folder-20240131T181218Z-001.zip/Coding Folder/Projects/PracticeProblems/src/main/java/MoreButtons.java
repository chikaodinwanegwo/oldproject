/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * @author chikaodinwanegwo
 */
public class MoreButtons extends JFrame {
    private JLabel frameTitle;
    private JButton exButton;
    private JButton cancelButton;
    
    
    public MoreButtons() {
        frameTitle = new JLabel("Login Frame", JLabel.CENTER);
        exButton = new JButton("Exit");
        cancelButton = new JButton("Cancel");
        
        exButton.setMnemonic('b');
        exButton.setToolTipText("Close Frame");
        
        cancelButton.setMnemonic('c');
        cancelButton.setToolTipText("Cancel Frame");
        
         add(frameTitle, BorderLayout.NORTH); 
        
       JPanel p = new JPanel();
        
       p.add(cancelButton);
       p.add(exButton);
       
       add(p, BorderLayout.SOUTH );
      
        
        
        exButton.addActionListener(new aButtons());
        
    }
        class aButtons implements ActionListener {
            public void actionPerformed(ActionEvent e){
                System.exit(0);
            }  
            
        }
        
        public static void main(String[] args){
            MoreButtons xyz = new MoreButtons();
            xyz.setVisible(true);
            xyz.setTitle("Login Frame");
            xyz.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            xyz.setLocationRelativeTo(null);
            xyz.setSize(300, 200);
        }
        
    }
    
    

