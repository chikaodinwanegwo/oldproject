/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * @author chikaodinwanegwo
 */
public class Practice1 extends JFrame{
    private JLabel Chikaodi1;
    private JButton nwanegwo;
    
    public Practice1(){
        Chikaodi1 = new JLabel("User Frame", JLabel.CENTER);
        nwanegwo = new JButton("Exit");
        
        nwanegwo.setMnemonic('b');
        nwanegwo.setToolTipText("Close Frame");
        
        setLayout(new FlowLayout());
        
        add(Chikaodi1);
        add(nwanegwo);
        
        nwanegwo.addActionListener(new yButtons());
    }
    
    class yButtons implements ActionListener {
        
        public  void actionPerformed(ActionEvent e) {
            System.exit(0);
            
        }
    }
    
    public static void main(String[] args){
        
        Practice1  h = new Practice1();
        h.setLocationRelativeTo(null);
        h.setVisible(true);
        h.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        h.setTitle("User Login");
        h.setSize(300, 200);
        
    }
}
