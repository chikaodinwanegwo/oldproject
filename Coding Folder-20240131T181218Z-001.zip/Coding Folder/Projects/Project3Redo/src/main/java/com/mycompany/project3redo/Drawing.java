/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.project3redo;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.*;

/**
 *
 * @author chikaodinwanegwo
 */
public class Drawing  extends JFrame implements ActionListener {
    
    //create Shape class reference
    
    Shape s = null;
    
    //declare required controls
    
    private JLabel shape, fillType, color, width, height,x, y, printCount;
    private JComboBox<String>cshape;
    private JComboBox<String>cfillType;
    private JComboBox<String>ccolor;
    private JTextField twidth, theight, tx, ty;
    private JButton draw;
    private JPanel panel;
    
    //declare variable
    
    int shapeWidth, shapeHeight, shapeX,shapeY;
    
    //default constructor
    
    public Drawing(){
        setSize(600,400); //set size to frame
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null); //set no layout
        setLocationRelativeTo(null);//centers frame
        setTitle("Geometric Drawing"); //title
        
        //instantiate all declared controls
        
        shape = new JLabel("Shape Type");
        fillType = new JLabel("Fill Type");
        color = new JLabel("Color");
        width = new JLabel("Width");
        height = new JLabel("Height");
        x = new JLabel("X Coordinate");
        y = new JLabel("Y Coordinate");
        printCount = new JLabel("1");
        
       cshape = new JComboBox<>(new String[]{"Oval", "Rectangle"});
       cfillType = new JComboBox<>(new String[]{"Solid", "Hollow"});
       ccolor = new JComboBox<>(new String[]{"Black","Red","Orange", "Yellow","Green","Blue", "Magenta"});
       twidth = new JTextField();
       theight = new JTextField();
       tx = new JTextField();
       ty = new JTextField();
       draw = new JButton("Draw");
       panel = new JPanel();
       
       //set border with title tp panel
       
       panel.setBorder(BorderFactory.createTitledBorder("Shape Drawing"));
       
       //add all controls into frame
       add(shape);
       add(fillType);
       add(color);
       add(color);
       add(width);
       add(height);
       add(x);
       add(y);
       add(printCount);
       add(cshape);
       add(cfillType);
       add(ccolor);
       add(twidth);
       add(theight);
       add(tx);
       add(ty);
       add(draw);
       add(panel);
       
       //set bounds for all controls
       
       shape.setBounds(20,20,100,30);
       fillType.setBounds(20,55,100,30);
       color.setBounds(20,90,100,30);
       width.setBounds(20, 125, 100, 30);
       height.setBounds(20,160, 100, 30);
       x.setBounds(20, 195, 100, 30);
       y.setBounds(200, 230, 100, 30);
       printCount.setBounds(285, 40, 20, 20);
       cshape.setBounds(140, 20, 100, 30);
       cfillType.setBounds(140, 55, 100, 30);
       ccolor.setBounds(140, 90, 100, 30);
       twidth.setBounds(140, 125, 100, 30);
       theight.setBounds(140, 160, 100, 30);
       tx.setBounds(140, 195, 100, 30);
       ty.setBounds(140, 230, 100, 30);
       draw.setBounds(230, 280, 80, 30);
       panel.setBounds(270, 20, 300, 250);
       
       // draw action listener to draw button
       
       draw.addActionListener(this);
       setVisible(true); //males frame visible
       
               
       
        
    }
    
    //method to check all possible excpetions
    private void checkException(){
        try{
            shapeWidth =Integer.parseInt(twidth.getText());
            shapeHeight =Integer.parseInt(theight.getText());
            shapeX =Integer.parseInt(tx.getText());
            shapeY=Integer.parseInt(ty.getText());
            
            if((shapeWidth+shapeX)> 300 || (shapeHeight+shapeY)>250 || shapeWidth<0 || shapeHeight<0 || shapeX<0 || shapeY<0)
                throw new OutsideBounds("Shape with entered Coordinates can not fit into panel....!!!!");
        }
        catch (OutsideBounds o){
            JOptionPane.showMessageDialog(null, o.getMessage());
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Please eneter valid dimension and coordinates...!!");
        }
    }
    
   @Override
   public void paint(Graphics g){
       try{
           //print count of shape
           printCount.setText(Shape.getNoOfShapes()+"");
           super.paintComponents(g);
           s.setColor(g);
           s.draw(g);
       }catch(Exception e) {}
       }
   }
  
  @Override
public void actionPerformed(ActionEvent arg0){
try{
    checkException();
        Point p = new Point(shapeX+270, shapeY+50);
        Dimension d = new Dimension(shapeWidth, shapeHeight);
        if(((String)cshape.getSelectedItem()).equalsIgnoreCase("oval"))
          s=new Oval(p,d,(String)color.getSelectedItem(), (String)cfillType.getSelectedItem());
        else
          s=new Rectangular(p,d,(String)ccolor.getSelectedItem(),(String)cfillType.getSelectedItem());
        repaint(); //call paint() method
        }catch(Exception e){}

}

}  
    

