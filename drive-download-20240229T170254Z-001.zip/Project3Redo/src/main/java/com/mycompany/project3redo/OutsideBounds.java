/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.project3redo;

/**
 *
 * @author chikaodinwanegwo
 */

//user defined exception
public class OutsideBounds extends Exception {
    //parameterized constructor
    
    public OutsideBounds(String errorMessage)
    {
        //call super class parameterized constructor
        super(errorMessage);
    }
    
}
