/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practiceproblems;
import java.util.LinkedList;
import java.util.ArrayList;
/**
 *
 * @author chikaodinwanegwo
 */
public class Week8 {
    public static void main(String[] args){
    ArrayList<String> Names = new ArrayList<String>();
    
    Names.add(" Peter");
    Names.add("Paul");
    Names.add(" Andrew");
    Names.add("Solomon");
    Names.add(" Juda");
    Names.add("Osborn");
    
    System.out.println("List the names of Everyone Taking martial arts   " +Names);
    
    long startTime = System.nanoTime();
    Names.get(1);
    long stopTime =System.nanoTime();
     
    long totalTime = stopTime - startTime;
    
    System.out.println("It took  " +totalTime+ "for ArrayList");
    
    LinkedList<String> LNames = new LinkedList<String>();
    
    LNames.add(" Peter");
    LNames.add("Paul");
    LNames.add(" Andrew");
    LNames.add("Solomon");
    LNames.add(" Juda");
    LNames.add("Osborn");
    
    System.out.println("List the names of Everyone Taking martial arts   " +Names);
    
    long starting = System.nanoTime();
    LNames.get(1);
    long ending =System.nanoTime();
    
    long timeDifference = ending - starting;
    
    System.out.println("It took  " +timeDifference+ "for LinkedLists");
    
    if(timeDifference < totalTime){
        System.out.println("Linked List is faster for retreiving the list of Names");
    } else if (totalTime < timeDifference){
        System.out.println("Array list is fater for retreiving the list of Names");
    }
}
}