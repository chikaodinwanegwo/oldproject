/**
* Print "My First Hello!" to standard output.
*/
public class UMGC
{
 public static void main(String[] args)
 {
  System.out.println("Welcome to CMIS 141 at UMGC!");
  System.out.println("Hope you will enjoy your school year this time");
  System.out.println("Wishing you all the best loves!");
 }

}
