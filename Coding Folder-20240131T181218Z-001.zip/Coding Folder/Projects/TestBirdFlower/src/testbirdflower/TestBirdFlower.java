/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testbirdflower;

import java.util.Scanner;

public class TestBirdFlower {
  
public static void main(String[] args) {
BirdFlower inform = new BirdFlower();
String stateName[][] = inform.getState();
String searchedState[] = new String[stateName.length];//Array to store search reasult
  
// Initialize scanner
Scanner userInput = new Scanner(System.in);
int searchCount = 0;
while (true) {
  
// Prompt user and scan user input
System.out.println("Enter a state name to see its bird and flower. Enter 'None' to exit the application.");
String stateInfo = userInput.nextLine();
  
// To ignore cap sensitivity and leading/trailing white spaces
if (stateInfo.trim().equalsIgnoreCase("None")) {
System.out.println("**** Thank you ***** \nA summary report for each State, Bird, and Flower is:");
//Iterating searchedState array to get each search reasult
for (int x = 0; x < searchedState.length; x++) {
if (searchedState[x] != null) {
System.out.println(searchedState[x]);
}
}
System.out.println("Please visit our site again!");
break;//breaking the mail while loop to exit
}
else {
int index = getStateIndex(stateInfo, stateName);
if (index != -1) {
System.out.println("Bird: " + getBird(index, stateName));
System.out.println("Flower: " + getFlower(index, stateName));
//Storing search reasult
searchedState[searchCount] = stateInfo +", " + getBird(index, stateName) + ", " + getFlower(index, stateName);
searchCount++;//increament vlid serach count
}
else {
System.out.println("Please input a valid state name.");
}
}
}
}
  
private static int getStateIndex(String stateInfo, String[][] stateName) {
for (int x = 0; x < stateName.length; x++) {
if (stateInfo.trim().equalsIgnoreCase(stateName[x][0])) {
return x;
}
}
return -1;
}
  
private static String getBird(int index, String[][] stateName) {
return stateName[index][1];
}
  
private static String getFlower(int index, String[][] stateName) {
return stateName[index][2];
}
}