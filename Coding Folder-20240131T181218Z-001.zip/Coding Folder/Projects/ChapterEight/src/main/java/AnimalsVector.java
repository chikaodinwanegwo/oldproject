/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
/**
 *
 * @author chikaodinwanegwo
 */

class Cat
{
    int i;
    public Cat(int j)
    {
        i = j;
    }
}
class Dog
{
    int i;
    public Dog(int j)
    {
        i = j;
    }
}
class Fish
{
        int i;
        public Fish(int j)
        {
            i = j;
        }
        
}
public class AnimalsVector {
    public static void main(String[] args)
    {
        //creat a vector object
        Vector animals = new Vector();
        
        //add animals
        animals.add(new Cat(2));
        animals.add(new Dog(5));
        animals.add(new Fish(9));
        
        //retrieve and downcast
        System.out.println("Displaying Animals");
        System.out.println("Cat number: " +((Cat)animals.get(0)).i);
        System.out.println("Dog number: " +((Dog)animals.get(1)).i);
        System.out.println("Fish number: "+ ((Fish)animals.get(2)).i);
                
    }
    
}
