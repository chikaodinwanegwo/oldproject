/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practiceproblems;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 *
 * @author chikaodinwanegwo
 */
public class FileLister extends JFrame {
    JLabel lblMsg = new JLabel("Type file: " );
    JTextField tf = new JTextField(25);
    JTextArea ta = new JTextArea(10,50);
    JButton btnShow = new JButton("Show File");
    
    public FileLister()
    {
        ta.setEditable(false);
        ta.setFont(new Font("Courier", Font.ITALIC, 12));
        
        
       Box box = Box.createHorizontalBox();
       box.add(lblMsg);
       box.add(tf);
       box.add(btnShow);
       add(box, BorderLayout.NORTH);
       
       JScrollPane pane = new JScrollPane(ta);
       add(pane, BorderLayout.CENTER);
       
       btnShow.addActionListener(new bselectL());
      // tf.addActionListener(new tfL());
    }
    
    class bselectL implements ActionListener{
        public void actionPerformed(ActionEvent e){
            showFile();
            
        }
    }
    public void showFile(){
        String fileName;
        if((fileName = tf.getText()).equals(""))
            fileName = "FileListener.java";
        
        String s;
        
        try
        {
            BufferedReader in = new BufferedReader(new FileReader(fileName));
            while((s = in.readLine()) !=null)
                ta.setText(ta.getText() +s+ "\n");
            in.close();
        
        } catch (IOException e1){}
       
    }
    
    public static void main(String[] args){
        FileLister f = new FileLister();
        
        //
        f.setTitle("File Lister");
        
        f.setSize(400, 500);
        f.setVisible(true);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
