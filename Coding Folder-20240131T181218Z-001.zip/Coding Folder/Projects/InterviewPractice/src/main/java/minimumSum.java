/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;
/**
 *
 * @author chikaodinwanegwo
 */
public class minimumSum {
    static int minSum(int arr[], int n){
        int sum = arr[0], prev = arr[0];
        for(int i = 1; i < n; i++ ){
            if(arr[i] <=prev){
                prev = prev + 1;
                sum = sum + prev;
            }
            else{
                sum = sum + arr[i];
                prev = arr[i];
            }
        }
        return sum;
    }
    
   public static void main(String[] args){
       int arr[] = {2, 2, 3, 5, 7};
       int n = arr.length;
       System.out.println(minSum(arr, n));
   }
    
}
        
    