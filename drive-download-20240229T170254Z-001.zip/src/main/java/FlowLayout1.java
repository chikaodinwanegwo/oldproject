/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author chikaodinwanegwo
 */
public class FlowLayout1 extends JFrame {
    // creates components 
   JLabel label;
   JButton Button;
   
   public FlowLayout1 ()
   {
       label = new JLabel("Login Frame", JLabel.CENTER);
       Button = new JButton("Exit");
       
       //set component properities if any
       Button.setMnemonic('b');
       Button.setToolTipText("Close frame");
       
       //set required layout
       setLayout(new FlowLayout());
       
       //add components to JFrame
       add(label);
       add(Button);
       
       //register listener for button
       
       Button.addActionListener(new PressButton());
   }
   
   class PressButton implements ActionListener{
       
       public void actionPerformed(ActionEvent e) {
           System.exit(0);
   }
       
 }
   public static void main(String[] args){
       FlowLayout1  c = new FlowLayout1();
       //frame properties
       c.setTitle("user Login");
       c.setSize(300,200);
       c.setLocationRelativeTo(null);
       c.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       c.setVisible(true);
   }
   
}
