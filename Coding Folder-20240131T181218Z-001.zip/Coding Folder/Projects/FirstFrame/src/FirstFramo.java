/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
/**
 *
 * @author chikaodinwanegwo
 */
public class FirstFramo 
    
{
    public static void main(String[] args)
    {
        JFrame f = new JFrame();
        f.setTitle("First Frame");
        f.setSize(300,200);
        f.setLocationRelativeTo(null);// centers to screen
        f.setVisible(true);
    }
}



