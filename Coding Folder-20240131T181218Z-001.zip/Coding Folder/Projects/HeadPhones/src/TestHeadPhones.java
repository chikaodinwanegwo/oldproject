
import headphones.HeadPhones;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class TestHeadPhones {
    public static void main(String[] args){
        //HeadPhones Testing
        HeadPhones[] testHeadPhones = new HeadPhones[4];
        //Default
        testHeadPhones[0] = new HeadPhones();
        testHeadPhones[1] = new HeadPhones(HeadPhones.HIGH, false,"Walgreens", "blue","HearingAif");
        testHeadPhones[2] = new HeadPhones(HeadPhones.LOW,true,"Walmart", "red","Beats");
        testHeadPhones[3] = new HeadPhones(HeadPhones.MEDIUM, false,"Bose","black","Apple");
        
        //each instance
        for(int i =0; i<testHeadPhones.length; i++){
            //to String method
            System.out.printf("\nHeadPhones %d",(i+1));
            System.out.printf("\ntestHeadPhones[i].toString()");
            //getter method
            System.out.print("\n Getter methods:");
            System.out.print("\nThe Volume is:" +testHeadPhones[i].getVolume() +
                    "\n Is it PluggedIn?" +testHeadPhones[i].getPluggedIn() + 
                    "\n Who's the Manufacturer?" +testHeadPhones[i].getManufacturer()+
                    "\n What's the Color? " +testHeadPhones[i].getHeadPhoneColor() +
                    "\n What's the Model?" +testHeadPhones[i].getHeadPhoneModel());
       
            //setting method
            System.out.println("\n Setting the Method");
            testHeadPhones[i].setVolume(HeadPhones.LOW);
            testHeadPhones[i].setPluggedIn(true);
            testHeadPhones[i].setManufacturer("UNKNOWN");
            testHeadPhones[i].setColor("Pink");
            testHeadPhones[i].setModel("Samsung");
            System.out.println(testHeadPhones[i].toString());
            
            //changing the volume
            System.out.println("Set the Volume to high, its too low");
            System.out.println("testHeadPhones[i].setVolume(HeadPhones.HIGH);");
            testHeadPhones[i].setVolume(HeadPhones.HIGH);
            System.out.println("The Volume has now been set to: " +testHeadPhones[i].getVolume());
        }//end class loop    
        
    } // end main method
}//end
  
            
    
        
        
        
               
        
    

