/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author chikaodinwanegwo
 */
public class lexiSomething {
    static String LexicographicalMaxString(String str){
        //loop to find max, substring in substring array
        
        String mx = " ";
        for(int i = 0; i < str.length(); ++i){
            if (mx.compareTo(str.substring(i)) <= 0) {
                mx = str.substring(i);
            }
        }
        return mx;
    }
    
    public static void main(String[] args)
    {
        //String str = "baca";
        //System.out.println(LexicographicalMaxString(str));
        
        Scanner input = new Scanner(System.in);
        String str = input.nextLine();
        System.out.println(LexicographicalMaxString(str));
        input.close();
    }
    
}
