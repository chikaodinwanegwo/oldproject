/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.project3redo;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
/**
 *
 * @author chikaodinwanegwo
 */

public abstract class Shape extends Rectangle{
    //instance variables
    
    private String color;
    private String shape;
    private static int count;
    
    //parameterized constructor
    public Shape(Point p, Dimension d, String color, String shape){
        super(p,d);
        this.color = color;
        this.shape = shape;
        count++;
    }
    
    //method to set color of the graphics
    public void setColor(Graphics g){
        if(color.equalsIgnoreCase("black"))
            g.setColor(Color.BLACK);
        else if (color.equalsIgnoreCase("red"))
            g.setColor(Color.RED);
        else if(color.equalsIgnoreCase("orange"))
            g.setColor(Color.ORANGE);
        else if(color.equalsIgnoreCase("yellow"))
            g.setColor(Color.YELLOW);
        else if(color.equalsIgnoreCase("green"))
            g.setColor(Color.GREEN);
        else if(color.equalsIgnoreCase("blue"))
            g.setColor(Color.BLUE);
        else if(color.equalsIgnoreCase("magenta"))
            g.setColor(Color.MAGENTA);
    }
    
    //return shape type solid or hollow
    public String getSolid(){
        return shape;
    }
    
    //return noOfShapes drawn
    public static int getNoOfShapes(){
        return count;
    }
    
    //abstract draw method
    public abstract void draw(Graphics g);
   
}

