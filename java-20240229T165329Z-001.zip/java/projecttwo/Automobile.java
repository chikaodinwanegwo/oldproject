/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projecttwo;
/**
 *
 * @author chikaodinwanegwo
 */
public class Automobile {
    public  String makeModel;
    public  double purchasePrice;
    
    
    public Automobile(String makeModel, double purchasePrice){
        this.makeModel = makeModel;
        this.purchasePrice = purchasePrice;
    }//end constructor of make and purchase price
    
    public double getSalesTax(){
        double salesTax = this.purchasePrice * .05;
        return salesTax;
       
    }// getSalesTax 
    
    public String toString(){
        
        return "Make and Model: " + this.makeModel +
                "\n Sales aprice: " + this.purchasePrice +
                "\n Sales Tax: " + this.getSalesTax();
                
    }// end of toString class
    
            
 }//ends class automobile
