/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
import java.awt.Dimension;
/**
 *
 * @author chikaodinwanegwo
 */
public class Drawing extends JPanel {
    
    private Shape PopUp;
    
    @Override
    protected void paintComponent(Graphics g){
        if(PopUp != null){
            PopUp.setColor(g);
            PopUp.Draw(g);
        }
       
    }

   @Override
   public Dimension getPreferredSize(){
       return new Dimension(200, 200);
       
   }
   
   
    public void drawShape (Shape cat) throws OutsideBounds {
        
       if(Double.compare((cat.getWidth() * cat.getHeight()), (super.getWidth() * super.getHeight())) > 0){
           throw new OutsideBounds("Try Again");
       }else{
        PopUp = cat;
        var l = super.getGraphics();
        paintComponent(l);
    }
       
       
    }        
    
}
