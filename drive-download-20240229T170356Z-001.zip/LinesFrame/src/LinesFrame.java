/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author chikaodinwanegwo
 */
class Lines extends JPanel
{
    public void paintComponent(Graphics g)
    {
        //super.paintComponent(g);
        g.setColor(Color.RED);
        g.setFont(new Font("Times", Font.BOLD, 24));
        g.drawString("Hello Java Frame", 100,100); // at(100,100)
        g.drawLine(100, 150, 300, 150); //(100, 150) to (300,150)
        g.drawLine(150, 200, 300, 250);
        g.drawLine(350, 100, 350, 200);
    }
}
    public class LinesFrame extends JFrame
    {
        Lines panel = new Lines();
        public LinesFrame()
        {
            add(panel);
            setTitle("Drawing Lines");
            setSize(400, 400);
            setLocationRelativeTo(null);//centers to screen
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// closes frame
            setVisible(true);
        }
       public static void main(String[] args)
       {
           LinesFrame f = new LinesFrame();
       }
    }


