/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;

/**
 *
 * @author chikaodinwanegwo
 */

class BallPanel extends JPanel{
    
    Random r = new Random();
    

          public void paintComponent (Graphics g) {
        
              super.paintComponent(g);
              //generate rgb values
              int red = r.nextInt(255);
              int green = r.nextInt(255);
              int blue = r.nextInt(255);
              // set the color 
              g.setColor(new Color(red, green, blue));
              
              //get random coord Values
              
               int x = r.nextInt(getWidth());
               int y = r.nextInt(getHeight());
               
               //draw circle
               g.fillOval(x, y, 25, 25);
               
               
          
    } 
}


public class ThrowBall extends JFrame {
    //Create components
    JButton bThrow = new JButton("Throw");
    JButton bExit = new JButton("Exit");
    
    //create ball panel
    
   BallPanel bPanel = new BallPanel();
   
   public ThrowBall(){
       
       //add bPanel to center
       add("Center", bPanel);
       
       //add buttons to south
       JPanel e = new JPanel();
       e.add(bThrow);
       e.add(bExit);
       add(e, BorderLayout.SOUTH);
       
       //register Listener for button
       bThrow.addActionListener(new BThrowL());
       bExit.addActionListener(new BExitL());
   }
   
   
    class BThrowL implements ActionListener
    {
        public void actionPerformed(ActionEvent e){
            bPanel.repaint();
        }
    }
    
    
    class BExitL implements ActionListener{
        public void actionPerformed(ActionEvent e){
            System.exit(0);
        }
    }

    
    public static void main(String[] args){
        //frame properties
        ThrowBall abcd = new ThrowBall();
        abcd.setVisible(true);
        abcd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        abcd.setLocationRelativeTo(null);
        abcd.setSize(400, 350);
        abcd.setTitle("Throwing Ball");
        
    }
}