/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chikaodinwanegwo
 */
public class Classes implements Class {
    int amount =10;
    int gpa = 4;
    
    Classes(int amount, int gpa){
        
    }
    @Override 
    public void vent(){
        System.out.println("Lack of sleep");
        System.out.println("Not enough time");
        System.out.println("Must Not QUIT");
    }
    @Override 
    public void Homework(){
        System.out.println("At least I have" + amount +"classes left and my GPA is currently" + gpa );
    }
    


    public static void main(String[] args){
       Classes x = new Classes(10, 4);
        x.vent();
        x.Homework();

}

}